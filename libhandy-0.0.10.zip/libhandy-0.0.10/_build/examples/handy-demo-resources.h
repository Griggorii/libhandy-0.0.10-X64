#ifndef __RESOURCE_hdy_H__
#define __RESOURCE_hdy_H__

#include <gio/gio.h>

G_GNUC_INTERNAL GResource *hdy_get_resource (void);
#endif
